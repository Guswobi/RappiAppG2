import 'package:flutter/material.dart';
import 'package:rapi_app/modelo/tienda_dto.dart';
import 'package:rapi_app/persistencia/producto_dao.dart';
import 'package:rapi_app/persistencia/tienda_dao.dart';

import 'listado_productos.dart';

class VistaTiendas extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Listado de tiendas',
      theme: ThemeData(
        // Define the default brightness and colors.
        primarySwatch: Colors.blue,
        // Define the default font family.
        fontFamily: 'Georgia',
        // Define the default `TextTheme`. Use this to specify the default
        // text styling for headlines, titles, bodies of text, and more.
        textTheme: const TextTheme(
          headline1: TextStyle(
              fontSize: 72.0, fontWeight: FontWeight.bold, color: Colors.white),
          headline6: TextStyle(
              fontSize: 36.0, fontStyle: FontStyle.italic, color: Colors.white),
          bodyText2: TextStyle(
              fontSize: 14.0, fontFamily: 'Hind', color: Colors.white),
        ),
      ),
      home: VistaListadoTiendas(),
    );
  }
}

class VistaListadoTiendas extends StatefulWidget {
  @override
  State<StatefulWidget> createState() {
    return _VistaListadoTiendasState();
  }
}

class _VistaListadoTiendasState extends State<VistaListadoTiendas> {
  final _stores = TiendasDao.tiendas;
  final _biggerFont = const TextStyle(fontSize: 26.0, color: Colors.white);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: AppBar(
          title: const Text('Lista de tiendas',
              style: TextStyle(fontSize: 35.0, color: Colors.white)),
        ),
        body: Container(
          width: double.infinity,
          decoration: BoxDecoration(
              gradient: LinearGradient(begin: Alignment.topCenter, colors: [
            Colors.blue.shade400,
            Colors.blue.shade600,
            Colors.blue.shade800
          ])),
          child: _buildStoresList(),
        ));
  }

  Widget _buildStoresList() {
    return ListView.builder(
        padding: const EdgeInsets.all(16.0),
        itemCount: _stores.length * 2,
        itemBuilder: (context, i) {
          if (i.isOdd) return const Divider();

          final index = i ~/ 2;

          return _buildRow(_stores[index]);
        });
  }

  Widget _buildRow(Tienda st) {
    return ListTile(
      title: Text(
        st.nombre,
        style: _biggerFont,
      ),
      subtitle: Text(
        st.direccion,
        style: TextStyle(fontSize: 20.0, color: Colors.blueGrey.shade100),
      ),
      leading: (Image.network(
          'https://drive.google.com/uc?export=view&id=' + st.logo)),
      trailing: Icon(
        Icons.add_call,
        color: Colors.white,
        size: 40.0,
      ),
      onTap: () {
        var pDao = ProductosDao();
        pDao.ObtenerProductosDelServidor(st.id).then((lista_productos) => {
              Navigator.push(
                context,
                MaterialPageRoute(
                    builder: (context) => VistaProductos(lista_productos, st)),
              ),
            });
      },
    );
  }
}
