import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:rapi_app/persistencia/conexion_http.dart';

class VistaNuevoCliente extends StatelessWidget {
  const VistaNuevoCliente({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Registro de nuevo cliente',
      theme: ThemeData(
        // Define the default brightness and colors.
        primarySwatch: Colors.grey,
        // Define the default font family.
        fontFamily: 'Georgia',
        // Define the default `TextTheme`. Use this to specify the default
        // text styling for headlines, titles, bodies of text, and more.
        textTheme: const TextTheme(
          headline1: TextStyle(
              fontSize: 72.0, fontWeight: FontWeight.bold, color: Colors.black),
          headline6: TextStyle(
              fontSize: 36.0, fontStyle: FontStyle.italic, color: Colors.black),
          bodyText2: TextStyle(
              fontSize: 14.0, fontFamily: 'Hind', color: Colors.black),
        ),
      ),
      home: Scaffold(
          appBar: AppBar(
              title: const Text('Registro de nuevo cliente',
                  style: TextStyle(fontSize: 25.0, color: Colors.black))),
          body: Container(
            width: double.infinity,
            decoration: BoxDecoration(
                gradient: LinearGradient(begin: Alignment.topCenter, colors: [
              Colors.black26,
              Colors.black38,
              Colors.black54
            ])),
            child: const FormularioNuevoCliente(),
          )),
    );
  }
}

class FormularioNuevoCliente extends StatefulWidget {
  const FormularioNuevoCliente({Key? key}) : super(key: key);

  @override
  FormularioNuevoClienteState createState() {
    return FormularioNuevoClienteState();
  }
}

class FormularioNuevoClienteState extends State<FormularioNuevoCliente> {
  final _formKey = GlobalKey<FormState>();
  late final String _nombre, _direccion, _telefono, _correo;

  @override
  Widget build(BuildContext context) {
    const estiloEtiqueta = TextStyle(fontSize: 20.0, color: Colors.black);

    return Form(
      key: _formKey,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text('Nombre.', style: estiloEtiqueta),
          TextFormField(
            validator: (value) {
              if (value == null || value.isEmpty) {
                return 'Por favor escriba su nombre.';
              } else {
                setState(() {
                  _nombre = value;
                });
                return null;
              }
            },
          ),
          const Text('Dirección.', style: estiloEtiqueta),
          TextFormField(
            validator: (value) {
              if (value == null || value.isEmpty) {
                return 'Por favor escriba su dirección.';
              } else {
                setState(() {
                  _direccion = value;
                });
                return null;
              }
            },
          ),
          const Text('Teléfono.', style: estiloEtiqueta),
          TextFormField(
            validator: (value) {
              if (value == null || value.isEmpty) {
                return 'Por favor escriba su teléfono.';
              } else {
                setState(() {
                  _telefono = value;
                });
                return null;
              }
            },
          ),
          const Text('Correo electrónico.', style: estiloEtiqueta),
          TextFormField(
            validator: (value) {
              if (value == null || value.isEmpty) {
                return 'Por favor escriba su correo electrónico.';
              } else {
                setState(() {
                  _correo = value;
                });
                return null;
              }
            },
          ),
          Padding(
            padding: const EdgeInsets.all(25.0),
            child: Center(
                child: ElevatedButton(
                  onPressed: () {
                    if (_formKey.currentState!.validate()) {
                      var con = ServerConnection();
                      con.insert('Clientes', _nombre + ';' + _direccion + ';' + _telefono + ';' + _correo);
                      ScaffoldMessenger.of(context).showSnackBar(
                        const SnackBar(
                            content:
                            Text('Datos guardados.', style: TextStyle(fontSize: 30.0, color: Colors.white))),
                      );
                    }
                    },
                  child: const Text('Registrar cliente', style: estiloEtiqueta),
                )),
          ),
        ],
      ),
    );
  }
}
