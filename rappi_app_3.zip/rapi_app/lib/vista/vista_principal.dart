import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:flutter/material.dart';
import 'package:rapi_app/modelo/tienda_dto.dart';
import 'package:rapi_app/persistencia/base_datos.dart';
import 'package:rapi_app/vista/listado_tiendas.dart';
import 'form_nuevo_cliente.dart';
import 'listado_productos.dart';

class RapiAppMainView extends StatefulWidget {
  @override
  State<RapiAppMainView> createState() => _RapiAppMainViewState();
}

class _RapiAppMainViewState extends State<RapiAppMainView> {
  List<String> images = [
    "images/listado_tiendas.png",
    "images/registro_clientes.png"
  ];

  @override
  void initState() {
    FirebaseMessaging.instance.getInitialMessage();
    FirebaseMessaging.onMessage.listen(
          (message) {
        if (message.notification != null) {
          print(message.notification!.body);
          print(message.notification!.title);
        }
        print(message);
      },
    );
    FirebaseMessaging.onMessageOpenedApp.listen(
          (messagge) {
        final routeMessagge = messagge.data["route"];
        print(routeMessagge);
      },
    );
    super.initState();
  }

  Widget _buildCelda(BuildContext context, int index) {
    return GestureDetector(
      onTap: () {
        if (index == 0) {
          Navigator.push(
            context,
            MaterialPageRoute(builder: (context) => VistaTiendas()),
          );
        } else if (index == 1) {
          Navigator.push(
            context,
            MaterialPageRoute(builder: (context) => VistaNuevoCliente()),
          );
        }
      },
      child: Container(
        padding: const EdgeInsets.symmetric(vertical: 15, horizontal: 15),
        child: Image.asset(images[index]),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Rapi app',
      theme: ThemeData(
        // Define the default brightness and colors.
        primarySwatch: Colors.red,
        // Define the default font family.
        fontFamily: 'Georgia',
        // Define the default `TextTheme`. Use this to specify the default
        // text styling for headlines, titles, bodies of text, and more.
        textTheme: const TextTheme(
          headline1: TextStyle(
              fontSize: 72.0, fontWeight: FontWeight.bold, color: Colors.red),
          headline6: TextStyle(
              fontSize: 36.0, fontStyle: FontStyle.italic, color: Colors.red),
          bodyText2:
              TextStyle(fontSize: 14.0, fontFamily: 'Hind', color: Colors.red),
        ),
      ),
      home: Scaffold(
        appBar: AppBar(
          title: Text(
            "Rapi app",
            style: TextStyle(fontSize: 35.0, color: Colors.white),
          ),
          backgroundColor: Colors.red,
        ),
        body: Container(
            width: double.infinity,
            decoration: BoxDecoration(
                gradient: LinearGradient(begin: Alignment.topCenter, colors: [
                  Colors.red.shade900,
                  Colors.red.shade600,
                  Colors.red.shade400
                ])),
            padding: EdgeInsets.all(12.0),
            child: GridView.builder(
              itemCount: images.length,
              gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                  crossAxisCount: 1,
                  mainAxisExtent: 225),
              itemBuilder: (context, index) => _buildCelda(context, index),
            )),
      ),
    );
  }
}
