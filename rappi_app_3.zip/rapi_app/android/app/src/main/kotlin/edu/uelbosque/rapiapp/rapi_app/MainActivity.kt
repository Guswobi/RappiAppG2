package edu.uelbosque.rapiapp.rapi_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
